﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApis.Models
{
    public class User_CartModel
    {
        int user_id { get; set; }
        int cart_id { get; set; }
    }
}